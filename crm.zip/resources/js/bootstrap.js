import smoothscroll from 'smoothscroll-polyfill';
import lodash from 'lodash';
import 'bootstrap';

window._ = lodash;
smoothscroll.polyfill();

export { default as Table } from './TableBase';

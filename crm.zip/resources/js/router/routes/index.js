import admin from './admin';
import guest from './guest';
import base from './base';

export default []
    .concat(admin)
    .concat(guest)
    .concat(base);

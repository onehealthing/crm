<template>
    <div class="h-100 d-flex align-items-center justify-content-center flex-column">
        <h3>404</h3>
        <span
            class="text-primary"
            role="button"
            @click="$router.back()"
        >Go back</span>
    </div>
</template>
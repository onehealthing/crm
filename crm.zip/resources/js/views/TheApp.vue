<template>
    <router-view></router-view>
</template>
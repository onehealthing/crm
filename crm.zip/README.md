## CRM
### Installation

```sh
composer install
npm install

php artisan migrate
php artisan passport:client --password
npm run dev
```

Configure .env
```
DB_CONNECTION=mysql
DB_HOST=
DB_PORT=3306
DB_DATABASE=
DB_USERNAME=
DB_PASSWORD=

LARAVEL_PASSPORT_CLIENT_ID=Client Id
LARAVEL_PASSPORT_CLIENT_SECRET=Client secret
```

##### In LaravelPassportService class you can see:
```
$response = $this->http->post('http://webserver/oauth/token'
```
##### I use 'webserver' because of docker-compose webserver module (See docker-compose.yml).

##### In .env you can see:
```
DB_HOST=db
```
##### I use 'db' because of docker-compose db module (See docker-compose.yml).
